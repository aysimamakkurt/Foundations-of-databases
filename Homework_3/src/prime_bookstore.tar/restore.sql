--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE prime_bookstore;
--
-- Name: prime_bookstore; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE prime_bookstore WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE prime_bookstore OWNER TO postgres;

\connect prime_bookstore

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Book_Store; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Book_Store";


ALTER SCHEMA "Book_Store" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Admin; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Admin" (
    "Admin_ID" integer NOT NULL,
    "Role" text NOT NULL,
    "Username" text NOT NULL,
    "Password" text NOT NULL
);


ALTER TABLE "Book_Store"."Admin" OWNER TO postgres;

--
-- Name: Admin_Admin ID _seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Admin_Admin ID _seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Admin_Admin ID _seq" OWNER TO postgres;

--
-- Name: Admin_Admin ID _seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Admin_Admin ID _seq" OWNED BY "Book_Store"."Admin"."Admin_ID";


--
-- Name: Author; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Author" (
    "Author_ID" integer NOT NULL,
    "Name" text NOT NULL,
    "Surname" text,
    "URL" text,
    "Email" text
);


ALTER TABLE "Book_Store"."Author" OWNER TO postgres;

--
-- Name: Author_Author ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Author_Author ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Author_Author ID_seq" OWNER TO postgres;

--
-- Name: Author_Author ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Author_Author ID_seq" OWNED BY "Book_Store"."Author"."Author_ID";


--
-- Name: Book; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Book" (
    "Title" text NOT NULL,
    "Price" numeric NOT NULL,
    "Pages" integer NOT NULL,
    "Language" text NOT NULL,
    "Description" text,
    "ISBN" text NOT NULL
);


ALTER TABLE "Book_Store"."Book" OWNER TO postgres;

--
-- Name: Category; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Category" (
    "Category_ID" integer NOT NULL,
    "Name" text NOT NULL
);


ALTER TABLE "Book_Store"."Category" OWNER TO postgres;

--
-- Name: Category_Category_ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Category_Category_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Category_Category_ID_seq" OWNER TO postgres;

--
-- Name: Category_Category_ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Category_Category_ID_seq" OWNED BY "Book_Store"."Category"."Category_ID";


--
-- Name: Copy; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Copy" (
    "Copy_ID" integer NOT NULL,
    "ISBN" text NOT NULL,
    "Warehouse_ID" integer NOT NULL,
    "Availibility" boolean NOT NULL
);


ALTER TABLE "Book_Store"."Copy" OWNER TO postgres;

--
-- Name: Copy_Book_ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Copy_Book_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Copy_Book_ID_seq" OWNER TO postgres;

--
-- Name: Copy_Book_ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Copy_Book_ID_seq" OWNED BY "Book_Store"."Copy"."Copy_ID";


--
-- Name: Customer; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Customer" (
    "Customer_ID" integer NOT NULL,
    "Name" text NOT NULL,
    "Address" text NOT NULL,
    "Email" text NOT NULL,
    "Surname" text NOT NULL,
    "Password" text NOT NULL,
    "Phone" text
);


ALTER TABLE "Book_Store"."Customer" OWNER TO postgres;

--
-- Name: Customer_Customer ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Customer_Customer ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Customer_Customer ID_seq" OWNER TO postgres;

--
-- Name: Customer_Customer ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Customer_Customer ID_seq" OWNED BY "Book_Store"."Customer"."Customer_ID";


--
-- Name: Has; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Has" (
    "Category_ID" integer NOT NULL,
    "ISBN" text NOT NULL
);


ALTER TABLE "Book_Store"."Has" OWNER TO postgres;

--
-- Name: Has_Category ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Has_Category ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Has_Category ID_seq" OWNER TO postgres;

--
-- Name: Has_Category ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Has_Category ID_seq" OWNED BY "Book_Store"."Has"."Category_ID";


--
-- Name: Invoice; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Invoice" (
    "Invoice_ID" integer NOT NULL,
    "Price" numeric NOT NULL,
    "Description" text,
    "Customer_ID" integer NOT NULL,
    "Timestamp" timestamp without time zone NOT NULL,
    "ISBN" text NOT NULL,
    "Copy_ID" integer NOT NULL,
    "Package_ID" integer NOT NULL
);


ALTER TABLE "Book_Store"."Invoice" OWNER TO postgres;

--
-- Name: Invoice_Customer ID _seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Invoice_Customer ID _seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Invoice_Customer ID _seq" OWNER TO postgres;

--
-- Name: Invoice_Customer ID _seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Invoice_Customer ID _seq" OWNED BY "Book_Store"."Invoice"."Customer_ID";


--
-- Name: Invoice_Invoice ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Invoice_Invoice ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Invoice_Invoice ID_seq" OWNER TO postgres;

--
-- Name: Invoice_Invoice ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Invoice_Invoice ID_seq" OWNED BY "Book_Store"."Invoice"."Invoice_ID";


--
-- Name: Message; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Message" (
    "Message_ID" integer NOT NULL,
    "Text" text NOT NULL,
    "Admin_ID" integer NOT NULL,
    "Customer_ID" integer NOT NULL,
    "timestamp" time without time zone NOT NULL
);


ALTER TABLE "Book_Store"."Message" OWNER TO postgres;

--
-- Name: Message_Admin ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Message_Admin ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Message_Admin ID_seq" OWNER TO postgres;

--
-- Name: Message_Admin ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Message_Admin ID_seq" OWNED BY "Book_Store"."Message"."Admin_ID";


--
-- Name: Message_Customer ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Message_Customer ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Message_Customer ID_seq" OWNER TO postgres;

--
-- Name: Message_Customer ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Message_Customer ID_seq" OWNED BY "Book_Store"."Message"."Customer_ID";


--
-- Name: Message_ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Message_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Message_ID_seq" OWNER TO postgres;

--
-- Name: Message_ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Message_ID_seq" OWNED BY "Book_Store"."Message"."Message_ID";


--
-- Name: Package; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Package" (
    "Package_ID" integer NOT NULL,
    weight numeric NOT NULL,
    "Shipping_Company_ID" integer NOT NULL,
    "Date" date NOT NULL
);


ALTER TABLE "Book_Store"."Package" OWNER TO postgres;

--
-- Name: Package_Package ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Package_Package ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Package_Package ID_seq" OWNER TO postgres;

--
-- Name: Package_Package ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Package_Package ID_seq" OWNED BY "Book_Store"."Package"."Package_ID";


--
-- Name: Package_Shipping Company ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Package_Shipping Company ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Package_Shipping Company ID_seq" OWNER TO postgres;

--
-- Name: Package_Shipping Company ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Package_Shipping Company ID_seq" OWNED BY "Book_Store"."Package"."Shipping_Company_ID";


--
-- Name: Published_by; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Published_by" (
    "Publisher_ID" integer NOT NULL,
    "Date" date NOT NULL,
    "ISBN" text NOT NULL
);


ALTER TABLE "Book_Store"."Published_by" OWNER TO postgres;

--
-- Name: Published by_Publisher ID _seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Published by_Publisher ID _seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Published by_Publisher ID _seq" OWNER TO postgres;

--
-- Name: Published by_Publisher ID _seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Published by_Publisher ID _seq" OWNED BY "Book_Store"."Published_by"."Publisher_ID";


--
-- Name: Publisher; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Publisher" (
    "Publisher_ID" integer NOT NULL,
    "Name" text NOT NULL,
    "URL" text,
    "Email" text,
    "Phone" text
);


ALTER TABLE "Book_Store"."Publisher" OWNER TO postgres;

--
-- Name: Publisher_Publisher ID_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Publisher_Publisher ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Publisher_Publisher ID_seq" OWNER TO postgres;

--
-- Name: Publisher_Publisher ID_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Publisher_Publisher ID_seq" OWNED BY "Book_Store"."Publisher"."Publisher_ID";


--
-- Name: ShippingCompany; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."ShippingCompany" (
    "Shipping_Company_ID" integer NOT NULL,
    "Name" text NOT NULL,
    "Phone" text
);


ALTER TABLE "Book_Store"."ShippingCompany" OWNER TO postgres;

--
-- Name: ShippingCompany_ShippingCompany_seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."ShippingCompany_ShippingCompany_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."ShippingCompany_ShippingCompany_seq" OWNER TO postgres;

--
-- Name: ShippingCompany_ShippingCompany_seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."ShippingCompany_ShippingCompany_seq" OWNED BY "Book_Store"."ShippingCompany"."Shipping_Company_ID";


--
-- Name: Warehouse; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Warehouse" (
    "Warehouse_ID" integer NOT NULL,
    "Address" text NOT NULL
);


ALTER TABLE "Book_Store"."Warehouse" OWNER TO postgres;

--
-- Name: Warehouse_Warehouse ID _seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Warehouse_Warehouse ID _seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Warehouse_Warehouse ID _seq" OWNER TO postgres;

--
-- Name: Warehouse_Warehouse ID _seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Warehouse_Warehouse ID _seq" OWNED BY "Book_Store"."Warehouse"."Warehouse_ID";


--
-- Name: Written_by; Type: TABLE; Schema: Book_Store; Owner: postgres
--

CREATE TABLE "Book_Store"."Written_by" (
    "Author_ID" integer NOT NULL,
    "Date" date,
    "ISBN" text NOT NULL
);


ALTER TABLE "Book_Store"."Written_by" OWNER TO postgres;

--
-- Name: Written by_Author ID _seq; Type: SEQUENCE; Schema: Book_Store; Owner: postgres
--

CREATE SEQUENCE "Book_Store"."Written by_Author ID _seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Book_Store"."Written by_Author ID _seq" OWNER TO postgres;

--
-- Name: Written by_Author ID _seq; Type: SEQUENCE OWNED BY; Schema: Book_Store; Owner: postgres
--

ALTER SEQUENCE "Book_Store"."Written by_Author ID _seq" OWNED BY "Book_Store"."Written_by"."Author_ID";


--
-- Name: Admin Admin_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Admin" ALTER COLUMN "Admin_ID" SET DEFAULT nextval('"Book_Store"."Admin_Admin ID _seq"'::regclass);


--
-- Name: Author Author_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Author" ALTER COLUMN "Author_ID" SET DEFAULT nextval('"Book_Store"."Author_Author ID_seq"'::regclass);


--
-- Name: Category Category_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Category" ALTER COLUMN "Category_ID" SET DEFAULT nextval('"Book_Store"."Category_Category_ID_seq"'::regclass);


--
-- Name: Copy Copy_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Copy" ALTER COLUMN "Copy_ID" SET DEFAULT nextval('"Book_Store"."Copy_Book_ID_seq"'::regclass);


--
-- Name: Customer Customer_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Customer" ALTER COLUMN "Customer_ID" SET DEFAULT nextval('"Book_Store"."Customer_Customer ID_seq"'::regclass);


--
-- Name: Invoice Invoice_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Invoice" ALTER COLUMN "Invoice_ID" SET DEFAULT nextval('"Book_Store"."Invoice_Invoice ID_seq"'::regclass);


--
-- Name: Message Message_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Message" ALTER COLUMN "Message_ID" SET DEFAULT nextval('"Book_Store"."Message_ID_seq"'::regclass);


--
-- Name: Message Admin_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Message" ALTER COLUMN "Admin_ID" SET DEFAULT nextval('"Book_Store"."Message_Admin ID_seq"'::regclass);


--
-- Name: Message Customer_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Message" ALTER COLUMN "Customer_ID" SET DEFAULT nextval('"Book_Store"."Message_Customer ID_seq"'::regclass);


--
-- Name: Package Package_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Package" ALTER COLUMN "Package_ID" SET DEFAULT nextval('"Book_Store"."Package_Package ID_seq"'::regclass);


--
-- Name: Package Shipping_Company_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Package" ALTER COLUMN "Shipping_Company_ID" SET DEFAULT nextval('"Book_Store"."Package_Shipping Company ID_seq"'::regclass);


--
-- Name: Published_by Publisher_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Published_by" ALTER COLUMN "Publisher_ID" SET DEFAULT nextval('"Book_Store"."Published by_Publisher ID _seq"'::regclass);


--
-- Name: Publisher Publisher_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Publisher" ALTER COLUMN "Publisher_ID" SET DEFAULT nextval('"Book_Store"."Publisher_Publisher ID_seq"'::regclass);


--
-- Name: ShippingCompany Shipping_Company_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."ShippingCompany" ALTER COLUMN "Shipping_Company_ID" SET DEFAULT nextval('"Book_Store"."ShippingCompany_ShippingCompany_seq"'::regclass);


--
-- Name: Warehouse Warehouse_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Warehouse" ALTER COLUMN "Warehouse_ID" SET DEFAULT nextval('"Book_Store"."Warehouse_Warehouse ID _seq"'::regclass);


--
-- Name: Written_by Author_ID; Type: DEFAULT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Written_by" ALTER COLUMN "Author_ID" SET DEFAULT nextval('"Book_Store"."Written by_Author ID _seq"'::regclass);


--
-- Data for Name: Admin; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Admin" ("Admin_ID", "Role", "Username", "Password") FROM stdin;
\.
COPY "Book_Store"."Admin" ("Admin_ID", "Role", "Username", "Password") FROM '$$PATH$$/3450.dat';

--
-- Data for Name: Author; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Author" ("Author_ID", "Name", "Surname", "URL", "Email") FROM stdin;
\.
COPY "Book_Store"."Author" ("Author_ID", "Name", "Surname", "URL", "Email") FROM '$$PATH$$/3452.dat';

--
-- Data for Name: Book; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Book" ("Title", "Price", "Pages", "Language", "Description", "ISBN") FROM stdin;
\.
COPY "Book_Store"."Book" ("Title", "Price", "Pages", "Language", "Description", "ISBN") FROM '$$PATH$$/3454.dat';

--
-- Data for Name: Category; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Category" ("Category_ID", "Name") FROM stdin;
\.
COPY "Book_Store"."Category" ("Category_ID", "Name") FROM '$$PATH$$/3455.dat';

--
-- Data for Name: Copy; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Copy" ("Copy_ID", "ISBN", "Warehouse_ID", "Availibility") FROM stdin;
\.
COPY "Book_Store"."Copy" ("Copy_ID", "ISBN", "Warehouse_ID", "Availibility") FROM '$$PATH$$/3457.dat';

--
-- Data for Name: Customer; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Customer" ("Customer_ID", "Name", "Address", "Email", "Surname", "Password", "Phone") FROM stdin;
\.
COPY "Book_Store"."Customer" ("Customer_ID", "Name", "Address", "Email", "Surname", "Password", "Phone") FROM '$$PATH$$/3459.dat';

--
-- Data for Name: Has; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Has" ("Category_ID", "ISBN") FROM stdin;
\.
COPY "Book_Store"."Has" ("Category_ID", "ISBN") FROM '$$PATH$$/3461.dat';

--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Invoice" ("Invoice_ID", "Price", "Description", "Customer_ID", "Timestamp", "ISBN", "Copy_ID", "Package_ID") FROM stdin;
\.
COPY "Book_Store"."Invoice" ("Invoice_ID", "Price", "Description", "Customer_ID", "Timestamp", "ISBN", "Copy_ID", "Package_ID") FROM '$$PATH$$/3463.dat';

--
-- Data for Name: Message; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Message" ("Message_ID", "Text", "Admin_ID", "Customer_ID", "timestamp") FROM stdin;
\.
COPY "Book_Store"."Message" ("Message_ID", "Text", "Admin_ID", "Customer_ID", "timestamp") FROM '$$PATH$$/3466.dat';

--
-- Data for Name: Package; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Package" ("Package_ID", weight, "Shipping_Company_ID", "Date") FROM stdin;
\.
COPY "Book_Store"."Package" ("Package_ID", weight, "Shipping_Company_ID", "Date") FROM '$$PATH$$/3470.dat';

--
-- Data for Name: Published_by; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Published_by" ("Publisher_ID", "Date", "ISBN") FROM stdin;
\.
COPY "Book_Store"."Published_by" ("Publisher_ID", "Date", "ISBN") FROM '$$PATH$$/3473.dat';

--
-- Data for Name: Publisher; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Publisher" ("Publisher_ID", "Name", "URL", "Email", "Phone") FROM stdin;
\.
COPY "Book_Store"."Publisher" ("Publisher_ID", "Name", "URL", "Email", "Phone") FROM '$$PATH$$/3475.dat';

--
-- Data for Name: ShippingCompany; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."ShippingCompany" ("Shipping_Company_ID", "Name", "Phone") FROM stdin;
\.
COPY "Book_Store"."ShippingCompany" ("Shipping_Company_ID", "Name", "Phone") FROM '$$PATH$$/3477.dat';

--
-- Data for Name: Warehouse; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Warehouse" ("Warehouse_ID", "Address") FROM stdin;
\.
COPY "Book_Store"."Warehouse" ("Warehouse_ID", "Address") FROM '$$PATH$$/3479.dat';

--
-- Data for Name: Written_by; Type: TABLE DATA; Schema: Book_Store; Owner: postgres
--

COPY "Book_Store"."Written_by" ("Author_ID", "Date", "ISBN") FROM stdin;
\.
COPY "Book_Store"."Written_by" ("Author_ID", "Date", "ISBN") FROM '$$PATH$$/3481.dat';

--
-- Name: Admin_Admin ID _seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Admin_Admin ID _seq"', 4, true);


--
-- Name: Author_Author ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Author_Author ID_seq"', 17, true);


--
-- Name: Category_Category_ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Category_Category_ID_seq"', 25, true);


--
-- Name: Copy_Book_ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Copy_Book_ID_seq"', 5, true);


--
-- Name: Customer_Customer ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Customer_Customer ID_seq"', 2, true);


--
-- Name: Has_Category ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Has_Category ID_seq"', 1, false);


--
-- Name: Invoice_Customer ID _seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Invoice_Customer ID _seq"', 1, false);


--
-- Name: Invoice_Invoice ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Invoice_Invoice ID_seq"', 2, true);


--
-- Name: Message_Admin ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Message_Admin ID_seq"', 1, false);


--
-- Name: Message_Customer ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Message_Customer ID_seq"', 1, false);


--
-- Name: Message_ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Message_ID_seq"', 4, true);


--
-- Name: Package_Package ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Package_Package ID_seq"', 3, true);


--
-- Name: Package_Shipping Company ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Package_Shipping Company ID_seq"', 1, false);


--
-- Name: Published by_Publisher ID _seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Published by_Publisher ID _seq"', 1, false);


--
-- Name: Publisher_Publisher ID_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Publisher_Publisher ID_seq"', 2, true);


--
-- Name: ShippingCompany_ShippingCompany_seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."ShippingCompany_ShippingCompany_seq"', 3, true);


--
-- Name: Warehouse_Warehouse ID _seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Warehouse_Warehouse ID _seq"', 3, true);


--
-- Name: Written by_Author ID _seq; Type: SEQUENCE SET; Schema: Book_Store; Owner: postgres
--

SELECT pg_catalog.setval('"Book_Store"."Written by_Author ID _seq"', 1, false);


--
-- Name: Admin Admin_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Admin"
    ADD CONSTRAINT "Admin_pkey" PRIMARY KEY ("Admin_ID");


--
-- Name: Author Author_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Author"
    ADD CONSTRAINT "Author_pkey" PRIMARY KEY ("Author_ID");


--
-- Name: Book Book_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Book"
    ADD CONSTRAINT "Book_pkey" PRIMARY KEY ("ISBN");


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY ("Category_ID");


--
-- Name: Copy Copy_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Copy"
    ADD CONSTRAINT "Copy_pkey" PRIMARY KEY ("Copy_ID");


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY ("Customer_ID");


--
-- Name: Has Has_Pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Has"
    ADD CONSTRAINT "Has_Pkey" PRIMARY KEY ("Category_ID", "ISBN");


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY ("Invoice_ID");


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY ("Message_ID");


--
-- Name: Package Package_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Package"
    ADD CONSTRAINT "Package_pkey" PRIMARY KEY ("Package_ID");


--
-- Name: Published_by Publishby_Pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Published_by"
    ADD CONSTRAINT "Publishby_Pkey" PRIMARY KEY ("ISBN", "Publisher_ID");


--
-- Name: Publisher Publisher_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Publisher"
    ADD CONSTRAINT "Publisher_pkey" PRIMARY KEY ("Publisher_ID");


--
-- Name: ShippingCompany ShippingCompany_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."ShippingCompany"
    ADD CONSTRAINT "ShippingCompany_pkey" PRIMARY KEY ("Shipping_Company_ID");


--
-- Name: Warehouse Warehouse_pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Warehouse"
    ADD CONSTRAINT "Warehouse_pkey" PRIMARY KEY ("Warehouse_ID");


--
-- Name: Written_by Written_by_Pkey; Type: CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Written_by"
    ADD CONSTRAINT "Written_by_Pkey" PRIMARY KEY ("ISBN", "Author_ID");


--
-- Name: Copy Copy_Fkey1; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Copy"
    ADD CONSTRAINT "Copy_Fkey1" FOREIGN KEY ("ISBN") REFERENCES "Book_Store"."Book"("ISBN") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Copy Copy_Fkey2; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Copy"
    ADD CONSTRAINT "Copy_Fkey2" FOREIGN KEY ("Warehouse_ID") REFERENCES "Book_Store"."Warehouse"("Warehouse_ID");


--
-- Name: Has Has_Fkey1; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Has"
    ADD CONSTRAINT "Has_Fkey1" FOREIGN KEY ("Category_ID") REFERENCES "Book_Store"."Category"("Category_ID") NOT VALID;


--
-- Name: Has Has_Fkey2; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Has"
    ADD CONSTRAINT "Has_Fkey2" FOREIGN KEY ("ISBN") REFERENCES "Book_Store"."Book"("ISBN") NOT VALID;


--
-- Name: Invoice Invoice_Fkey1; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Invoice"
    ADD CONSTRAINT "Invoice_Fkey1" FOREIGN KEY ("ISBN") REFERENCES "Book_Store"."Book"("ISBN") NOT VALID;


--
-- Name: Invoice Invoice_Fkey2; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Invoice"
    ADD CONSTRAINT "Invoice_Fkey2" FOREIGN KEY ("Copy_ID") REFERENCES "Book_Store"."Copy"("Copy_ID") NOT VALID;


--
-- Name: Invoice Invoice_Fkey3; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Invoice"
    ADD CONSTRAINT "Invoice_Fkey3" FOREIGN KEY ("Customer_ID") REFERENCES "Book_Store"."Customer"("Customer_ID") NOT VALID;


--
-- Name: Invoice Invoice_Fkey4; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Invoice"
    ADD CONSTRAINT "Invoice_Fkey4" FOREIGN KEY ("Package_ID") REFERENCES "Book_Store"."Package"("Package_ID") NOT VALID;


--
-- Name: Message Message_Fkey; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Message"
    ADD CONSTRAINT "Message_Fkey" FOREIGN KEY ("Admin_ID") REFERENCES "Book_Store"."Admin"("Admin_ID");


--
-- Name: Message Message_Fkey2; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Message"
    ADD CONSTRAINT "Message_Fkey2" FOREIGN KEY ("Customer_ID") REFERENCES "Book_Store"."Customer"("Customer_ID");


--
-- Name: Package Package_Fkey; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Package"
    ADD CONSTRAINT "Package_Fkey" FOREIGN KEY ("Shipping_Company_ID") REFERENCES "Book_Store"."ShippingCompany"("Shipping_Company_ID") NOT VALID;


--
-- Name: Published_by Publisheby_Fkey2; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Published_by"
    ADD CONSTRAINT "Publisheby_Fkey2" FOREIGN KEY ("ISBN") REFERENCES "Book_Store"."Book"("ISBN") NOT VALID;


--
-- Name: Published_by Publishedby_Fkey1; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Published_by"
    ADD CONSTRAINT "Publishedby_Fkey1" FOREIGN KEY ("Publisher_ID") REFERENCES "Book_Store"."Publisher"("Publisher_ID") NOT VALID;


--
-- Name: Written_by Writtenby_Fkey1; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Written_by"
    ADD CONSTRAINT "Writtenby_Fkey1" FOREIGN KEY ("Author_ID") REFERENCES "Book_Store"."Author"("Author_ID") NOT VALID;


--
-- Name: Written_by Writtenby_Fkey2; Type: FK CONSTRAINT; Schema: Book_Store; Owner: postgres
--

ALTER TABLE ONLY "Book_Store"."Written_by"
    ADD CONSTRAINT "Writtenby_Fkey2" FOREIGN KEY ("ISBN") REFERENCES "Book_Store"."Book"("ISBN") NOT VALID;


--
-- PostgreSQL database dump complete
--

